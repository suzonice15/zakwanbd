
    @include('website.includes.header')

    @yield('mainContent')

    @include('website.includes.footer')
