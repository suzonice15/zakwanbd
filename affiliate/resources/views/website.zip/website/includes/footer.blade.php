<style>


    @media  (max-width:600px) {

        .left_image_class{
            list-style: none;float: left;
            margin-left: -34px;
        }
    }
    .left_image_class{
        list-style: none;float: left;
        margin-left: 28px;

    }

</style>

<footer>

        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    
                    <a href="https://www.sohojaffiliates.com/storage/sohojaffiliates.apk" download>
                    <img src="https://www.sohojbuy.com/public/uploads/Google-Play.png"
                         title="Google-Play-footer-" width="100" height="50">
                        
                        </a>

                    <img src="https://www.sohojbuy.com/public/uploads/App-Store.png" title="App-Store-footer-"
                         width="100" height="50">

                    <div class="copy-right-text">
                        <p class="made-in-bd"> Address: Shah Ali Plaza, Mirpur 10 Roundabout, Dhaka 1216.</p>
                        <p>© 2017-2020 All rights reserved.</p>
                        <p>Phone Number: 01300884747</p>
                        <p>Email: Support@sohojaffiliates.com</p>
                    </div>
                </div>


                <div class="col-md-3">
                    <ul class="social-network">
                        <li><a href="https://www.facebook.com/SohojAffiliates/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a>
                        </li>
                        <li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a>
                        </li>
                        
                    </ul>

                    <ul id="menu-footer-bottom-menu" class="single-menu-item">
                        <li style="list-style: none;float: left"
                           ><a
                                href="{{url('/')}}/terms-conditions">Terms &amp; Conditions</a></br>
                                <a
                                href="{{url('/')}}/privacy">Privacy Policy</a>
                            </li>
                        
                    </ul>
                    
                </div>
                <div class="col-md-4">

                    <h4 style="text-align: center;" >Payments Method</h4>
                    <ul id="menu-footer-bottom-menu" class="single-menu-item" style="margin-top: 5px;">
                        <li  class="left_image_class" >
                            <img src="{{url('/')}}/public/logo/nagad.png" height="40px" width="45px" style="margin-left: 3px;">
                            <img src="{{url('/')}}/public/logo/bkash.png" style="float: left;margin-left: 3px;" height="40px" width="45px">
                            <img src="{{url('/')}}/public/logo/rocket.png" style="float: left; margin-left: 3px;" height="40px" width="45px">
                        </li>
                        <li
                                style="list-style: none;float: right">

                            <img src="{{url('/')}}/public/logo/brack.png" height="40px" width="45px" style="margin-left: 3px;">
                            <img src="{{url('/')}}/public/logo/dbbl.png" style="float: left;margin-left: 3px;" height="40px" width="45px">
                            <img src="{{url('/')}}/public/logo/islamic.png" style="float: left; margin-left: 3px;" height="40px" width="45px">

                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>

    </footer>
    <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

</div>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="{{ asset('assets/font_end/')}}/js/bootstrap.min.js"></script>



<script>
    
    
    let width_dektop=$(window).width();
    
if(width_dektop<700){
    
    
 $('.remove_class').removeClass('desktop_image');
           

          
       

}
</script>

</body>
</html>