<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?=get_option('site_title')?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="নাম্বার ১ অ্যাফিলিয়েট প্ল্যাটফর্ম"/>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="নাম্বার ১ অ্যাফিলিয়েট প্ল্যাটফর্ম" />
    <meta property="og:description" content="সহজ এফিলিয়েটে কাজ শুরু করতে কোন টাকা পয়সা লাগেনা। স্টেপ বাই স্টেপ গাইডলাইন এবং টারগেট আপনাকে এগিয়ে নিয়ে যাবে কাঙ্খিত লক্ষ্যে।" />
    <meta property="og:image" content="https://www.sohojbuy.com/public/uploads/banner.jpg"/>
	<meta name="twitter:card" content="summary_large_image" />


    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-187297173-2"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-187297173-2');
    </script>
   
    <link href="{{ asset('assets/font_end/')}}/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="{{ asset('assets/font_end/')}}/css/style.css" rel="stylesheet"/>


    <!-- Theme skin -->
    <link href="{{ asset('assets/font_end/')}}/css/default.css" rel="stylesheet"/>
    <script src="{{ asset('assets/font_end/')}}/js/jquery.js"></script>


    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <style>
    
    .responsive_mobile{
        margin-right: -48px !important;
    }
    .logo{
      width: 250px;margin-top: -9px;  
        
    }
    .why_you_work_inaffilite{
        
        margin-top: 205px;
    }

.mother_heading{
    
    margin-top: 106px;line-height: 60px;
}
.mother_heading_bottom{
    
    font-weight: normal;font-size: 17px;font-weight: bold;text-align: left;
}
.why_affilite_work{
    
    
    text-align: center;
margin-bottom: 55px;
margin-top: 54px;
}

        .start_now {
            background-color: #ff8100;
            display: block;
            text-align: center;
            padding: 12px;
            color: white;
            font-size: 19px;
            width: 82%;
        }

        .fun-facts-info {
            border-right: 2px solid #ddd;
        }
 

        @media only screen and (max-width: 600px) {
            .fun-facts-info {
               border-right: 0px solid #ddd;
text-align: center;
border-bottom: 1px solid #ddd;
            }
            .fun-facts-info0{
                 border-right: 0px solid #ddd;
text-align: center;
                 
            }
            .mobile{
                
                background-color: #dddddd;
width: 115%;
                
            }
            
            
.mother_heading{
    
   margin-top: -30px;
line-height: 43px;
font-size: 26px;
text-align: center;
}
.mother_heading_bottom{
    
    font-weight: normal;font-size: 17px;font-weight: normal;text-align: center;
}

.why_affilite_work{
    
   text-align: center;
margin-bottom: 50px;
font-size: 22px;
}


.start_now {
  background-color: green;
display: block;
text-align: center;
padding: 15px;
color: white;
font-size: 17px;
width: 47%;
margin-left: 85px;
 border-radius: 5px;
}


.why_you_work_inaffilite{
        
       margin-top: 399px;
    }
    
    
     
    .logo{
     width: 250px;
/*margin-top: -95px;*/
        
    }
    .image_class{
   display: block !important;
width: 353px;
height: 405px;
}

.bg-image {
    background-size: 540px;
}



 .responsive_mobile{
        margin-right: 0px; 
    }
    .desktop_image{
        background-image:none;
        
         background-position: center top ;
    
}

        }
        @media(max-width: 363px){
            .logo{
                margin-top: -8px;
                width: 210px;
            }
        }
    </style>
</head>
<body>
 
    <!-- start header -->
    
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">
                
                
      
    <header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container-fluid" style="box-shadow: 0 1px 4px rgba(0,0,0,0.06);height: 85px;">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="{{url('/')}}"><img class="logo" 
                                                                   src="https://www.sohojbuy.com/public/uploads/logo.png"></a>
                </div>
                <div class="navbar-collapse collapse mobile pull-right responsive_mobile">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="{{url('/')}}/how-to-sart">কিভাবে শুরু করবো </a></li>
                        <li class="active"><a href="{{url('/')}}/faq">FAQ</a></li>
                        <li class="active"><a href="{{url('/')}}/login">Login</a></li>
                        <li><a href="{{url('/')}}/registration">Signup</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </header>
    
          </div>
        </div>
    </div>