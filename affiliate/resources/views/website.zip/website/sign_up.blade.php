
@extends('website.master')
@section('mainContent')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>

        .input-container {
            display: -ms-flexbox; /* IE10 */
            display: flex;
            width: 100%;
            margin-bottom: 15px;
        }

        .icon {
            padding: 18px;
            background: dodgerblue;
            color: white;
            min-width: 50px;
            text-align: center;
        }

        .input-field {
            width: 100%;
            padding: 10px;
            outline: none;
        }

        .input-field:focus {
            border: 2px solid dodgerblue;
        }

        /* Set a style for the submit button */
        .btn {
            background-color: dodgerblue;
            color: white;
            padding: 15px 20px;
            border: none;
            cursor: pointer;
            width: 20%;
            opacity: 0.9;
        }

        .btn:hover {
            opacity: 1;
        }
    </style>

    <form action="{{url('registration')}}"  method="post" style="max-width:500px;margin:auto;margin-top: 100px;min-height: 600px">

        @csrf




        <?php $success=Session::get('success');

        if($success){

        ?>
        <h3 style="color: green;
border: 2px solid green;
padding: 12px;
font-size: 23px;">
            <p>আপনার ইমেইলে একটি ভেরিফিকেশন লিংক পাঠানো হয়েছে। লিংকে ক্লিক করে ভেরিফিকেশন সম্পন্ন করুন। Inbox এ মেইল না পেলে Spam বা Junk ফোল্ডার চেক করুন।</p>

        </h3>

        <?php } ?>


        <h3 style="color:red">{{Session::get('error')}}</h3>

       <?php  if(empty($success)){ ?>
        <h2>Register Form</h2>
        <div class="input-container">
            <i class="fa fa-envelope icon"></i>
            <input class="input-field" type="text" placeholder="Email" id="email" name="email" autocomplete="off">
            <input type="button" id="varify" class="btn btn-success" value="Verify">

        </div>
        <div class="input-container fieldHiden">
            <i class="fa fa-user icon"></i>
            <input class="input-field" type="text" placeholder="Full Name" name="name" autocomplete="off">
        </div>



        <div class="input-container">

            <span id="email_varify_show"  style="display:block;color:black;position: absolute;right: 380px;font-weight: bolder;"> Click varify button to varify your email </span>

        </div>
        <div class="input-container varificationClassSectionHide">

            <span id="success" style="display:none;color:green">আপনার ইমেইলে একটি ভেরিফিকেশন কোড গেছে এই কোডটি নিচের বক্সে বসান
                            ইনবক্সে না পেলে   স্পাম ফোল্ডার চেক করেন</span>
            <p class="email_error" class="text-danger">


            </p>
            <input type="hidden" id="varificationServerCode">

        </div>
        <div class="input-container varificationClassSectionHide">

            <input class="input-field" type="text" placeholder="Enter Your Varification Code" name="varify_code" id="varify_code" autocomplete="off">
            <i id="checked" class="fa fa-check-square" style="color:green;font-size: 25px"></i>
            <input type="hidden" id="varification_code_check"  name="varification_code_check" value="{{Session::get('code')}}">

            <button type="button"  style="display:none" id="varifyCodeCheck" class="btn btn-info"> Submit</button>
        </div>



        <div class="input-container fieldHiden">
            <i class="fa fa-phone icon"></i>
            <input class="input-field" required="" type="text" placeholder="Phone" id="customer_phone" name="phone" autocomplete="off">
            <span id="customer_phone_error"></span>
        </div>
        <div class="input-container">

            <span id="customer_phone_error"></span>
        </div>

        <div class="input-container fieldHiden">
            <i class="fa fa-key icon"></i>
            <input class="input-field" type="password" placeholder="Password" name="password" autocomplete="off">
        </div>
        <div class="input-container fieldHiden">
            <i class="fa fa-user icon"></i>
            <!-- <input class="input-field" type="hidden" placeholder="Referal" name="parent_id" value="<?php //echo  Cookie::get('referrer_user')?>" autocomplete="off"> -->
            <input class="input-field" type="text" placeholder="Referal (Optional)" name="parent_id" value="<?php echo  Cookie::get('referrer_user')?>" autocomplete="off">
        </div>

        <button type="submit" id=form_submit" class="btn btn-info fieldHiden">Register</button>
       <span class="fieldHiden"> Already have an account ? </span> <a class="fieldHiden" href="{{URL::to('login')}}" style="color:dodgerblue">Sign in</a>
        <?php } ?>

    </form>
    <script>

        jQuery('form#checkout #customer_phone').on('blur', function () {

            var customer_phone= jQuery('#customer_phone').val();

            if (!/^01\d{9}$/.test(customer_phone)) {
                return false;
                jQuery('#customer_phone_error').text("Invalid phone number: must have exactly 11 digits and begin with ");
            } else {
                jQuery('#customer_phone_error').text(" ");
                return true;

            }

        });


    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.fieldHiden').hide();

            $('#varifyCodeCheck').click(function(){
                var customerCode=$("#varify_code").val();
                var serverCode=$("#varificationServerCode").val();
                if(serverCode===customerCode){
                    $('.fieldHiden').show();
                    $('.varificationClassSectionHide').hide();
                } else {

                    alert("Your Varification Code does not matched")
                }
            });
            $('#checked').hide();
            $('#success').hide();
            $(document).on('input','#varify_code', function () {
               let varify_code= $('#varify_code').val();
               let varification_code_check= $('#varification_code_check').val();
                if(varification_code_check==varify_code){
                    $('#checked').show();
                } else {

                    $('#checked').hide();

                }


            });

            $('#varify_code').hide();
            $(':input[type="submit"]').prop('disabled', true);
            $('#varify').click(function(){

                var email = $('#email').val();
                if(email== ''){
                    $('.email_error').html('<span style="color:red">Please Enter Your Email</span>');
                    $('#email_varify_show').hide();
                }
                if(IsEmail(email)==false){
                    $('.email_error').html('<span style="color:red">Please Enter Your Valid  Email</span>');
                    $('#email_varify_show').hide();

                } else {



                $.ajax({
                    type:"GET",
                    url:"{{url('affilite/email_check')}}?email="+email,
                    success:function(data)
                    {



                        if(data=='no'){
                            $('.email_error').html('<span style="color:red">This   Email exits in our database try another </span>');
                            $('#email_varify_show').hide();
                        } else {


                            $('#success').show();
                            $('#varifyCodeCheck').show();
                            $('#varify_code').show();
                            $('.email_error').html('');
                             $('#varify').hide();
                            $('#email_varify_show').hide();
                            $(':input[type="submit"]').prop('disabled', false);
                            $('#varificationServerCode').val(data);


                        }
                    }
                });

            }
        });
        });
        function IsEmail(email) {
            var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!regex.test(email)) {
                return false;
            }else{
                return true;
            }
        }
    </script>


@endsection
